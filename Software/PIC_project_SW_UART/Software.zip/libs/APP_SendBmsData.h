

void sendCellVoltages();
void sendBmsStatus();
void sendCellBalancingStatus();
void sendCellMaxBalancing();
void sendCellMaxVoltage();
void sendCellMinVoltage();

unsigned char sendCellVoltages_send=0;
unsigned char sendBmsStatus_send=0;
unsigned char sendCellBalancingStatus_send=0;
unsigned char sendCellMaxBalancing_send=0;
unsigned char sendCellMaxVoltage_send=0;
unsigned char sendCellMinVoltage_send=0;