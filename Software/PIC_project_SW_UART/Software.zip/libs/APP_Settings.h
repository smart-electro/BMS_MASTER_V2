void checkForCan();
unsigned char bms_id;
void readSettings();