#include<adc.h>

#define ADC_ChanalNo 4
#define ADC_SampleNo 16
int ADC_result[ADC_ChanalNo];
void ADC_Init(void);

void ADC_Data(void);

