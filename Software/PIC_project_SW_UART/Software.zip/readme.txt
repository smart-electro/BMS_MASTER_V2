project for MPLAB IDE v8.92 and C18 compiler
